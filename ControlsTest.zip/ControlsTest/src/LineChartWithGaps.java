/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javafx.scene.chart.*;
import java.util.List;
import javafx.beans.NamedArg;

public class LineChartWithGaps extends LineChart<Number, Number> {

    List<Integer> gapIndexes;

    public LineChartWithGaps() {
        this(new NumberAxis(), new NumberAxis(), null);
    }

    public LineChartWithGaps(@NamedArg("xAxis") Axis<Number> xAxis,
                             @NamedArg("yAxis") Axis<Number> yAxis,
                             List<Integer> gapIndexes) {
        super(xAxis, yAxis);
        this.gapIndexes = gapIndexes;
    }

    @Override
    protected void layoutPlotChildren() {
        super.layoutPlotChildren();
    }
}
